-- phpMyAdmin SQL Dump
-- version 2.6.4-pl4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 28, 2017 at 08:02 AM
-- Server version: 4.0.26
-- PHP Version: 4.4.3-dev
-- 
-- Database: `lldb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `academicyear`
-- 

CREATE TABLE `academicyear` (
  `ACYId` varchar(12) NOT NULL default '',
  `StartDate` date NOT NULL default '0000-00-00',
  `EndDate` date NOT NULL default '0000-00-00',
  `Semestry` int(3) NOT NULL default '0',
  PRIMARY KEY  (`ACYId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `academicyear`
-- 

INSERT INTO `academicyear` VALUES ('SE0012016', '2016-08-09', '2017-08-10', 2);
INSERT INTO `academicyear` VALUES ('SE002017', '2017-01-09', '2017-12-10', 6);
INSERT INTO `academicyear` VALUES ('AY003019', '2017-02-12', '2019-12-10', 9);
INSERT INTO `academicyear` VALUES ('AY008080', '2017-01-01', '2018-01-10', 3);
INSERT INTO `academicyear` VALUES ('AY007767', '2017-02-20', '2017-08-20', 2);
INSERT INTO `academicyear` VALUES ('AY003300', '2017-04-01', '2019-08-20', 5);
INSERT INTO `academicyear` VALUES ('AY003333', '2016-12-01', '2017-12-20', 2);
INSERT INTO `academicyear` VALUES ('AY003221', '2017-01-30', '2017-07-03', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `administratortbl`
-- 

CREATE TABLE `administratortbl` (
  `AdminId` varchar(12) NOT NULL default '',
  `NICNumber` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`AdminId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `administratortbl`
-- 

INSERT INTO `administratortbl` VALUES ('Admin0001', '909125430v');
INSERT INTO `administratortbl` VALUES ('Admin0002', '929125432v');
INSERT INTO `administratortbl` VALUES ('Admin0003', '939125433v');
INSERT INTO `administratortbl` VALUES ('Admin0004', '949125434v');
INSERT INTO `administratortbl` VALUES ('Admin0005', '959125435v');
INSERT INTO `administratortbl` VALUES ('Admin006', '969125436v');
INSERT INTO `administratortbl` VALUES ('Admin0007', '989125436v');

-- --------------------------------------------------------

-- 
-- Table structure for table `assignmentitem`
-- 

CREATE TABLE `assignmentitem` (
  `AssignmentId` varchar(12) NOT NULL default '',
  `EC_ClaimId` varchar(249) NOT NULL default '',
  `Subject` varchar(40) NOT NULL default '',
  `Grade` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`AssignmentId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `assignmentitem`
-- 

INSERT INTO `assignmentitem` VALUES ('AS0001', 'img2017/03/24CHC_Guide_for_Teachers_TEs.pdf', 'Software Engineering', 'Pass Grade');
INSERT INTO `assignmentitem` VALUES ('AS002', 'img2017/03/24plantiff 1.docx', 'Network Engineering', 'C Pass');
INSERT INTO `assignmentitem` VALUES ('As0003', 'img2017/03/24Weerawansa V. The Attorney ...pdf', 'Dip In Enlish', 'D Pass');
INSERT INTO `assignmentitem` VALUES ('AS004', 'img2017/03/24U new.docx', 'Dip In Multy Meadia', 'Fail');
INSERT INTO `assignmentitem` VALUES ('AS0007', 'img2017/03/2', 'DSC in Medicing', 'D Pass');

-- --------------------------------------------------------

-- 
-- Table structure for table `ecclaim`
-- 

CREATE TABLE `ecclaim` (
  `NICNumber` varchar(12) NOT NULL default '',
  `EC_ClaimId` varchar(240) NOT NULL default '',
  `Description` varchar(100) NOT NULL default '',
  `Link` varchar(240) NOT NULL default '',
  `UploadDate` date NOT NULL default '0000-00-00',
  `FacultyId` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`,`EC_ClaimId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `ecclaim`
-- 

INSERT INTO `ecclaim` VALUES ('922500240v', 'Document/_Ex_Parte_Pinochet_Cook__Helena_.pdf', 'Medical Claim Submission', 'Document/_Ex_Parte_Pinochet_Cook__Helena__1999.pdf', '2017-03-24', 'NE001');
INSERT INTO `ecclaim` VALUES ('8725002400v', 'img2017/03/2', 'Education leave Claim', 'Document/Deed book nalaka aiyya pdf new.pdf', '2017-03-24', 'SE001');
INSERT INTO `ecclaim` VALUES ('8725002400v', 'img2017/03/24CHC_Guide_for_Teachers_TEs.pdf', 'Was Accident', 'Document/CHC_Guide_for_Teachers_TEs.pdf', '2017-03-24', 'SE001');
INSERT INTO `ecclaim` VALUES ('8725002400v', 'img2017/03/24plantiff 1.docx', 'Medical Claim Submission', 'Document/plantiff 1.docx', '2017-03-24', 'NE001');
INSERT INTO `ecclaim` VALUES ('8725002400v', 'img2017/03/24Weerawansa V. The Attorney ...pdf', 'Medical Claim Submission', 'Document/Weerawansa V. The Attorney ...pdf', '2017-03-24', 'NE001');
INSERT INTO `ecclaim` VALUES ('8725002400v', 'img2017/03/24U new.docx', 'Education leave Claim', 'Document/U new.docx', '2017-03-24', 'SE001');

-- --------------------------------------------------------

-- 
-- Table structure for table `eccoordinatortbl`
-- 

CREATE TABLE `eccoordinatortbl` (
  `ECCId` varchar(12) NOT NULL default '',
  `NICNumber` varchar(12) NOT NULL default '',
  `facultyId` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`ECCId`,`NICNumber`,`facultyId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `eccoordinatortbl`
-- 

INSERT INTO `eccoordinatortbl` VALUES ('ECC001', '922500251v', 'SE001');
INSERT INTO `eccoordinatortbl` VALUES ('ECC002', '922500250v', ' NE001');
INSERT INTO `eccoordinatortbl` VALUES ('ECC012', '932500241v', 'DipE001');
INSERT INTO `eccoordinatortbl` VALUES ('ECC023', '922500240v', 'NE001');
INSERT INTO `eccoordinatortbl` VALUES ('ECC034', '962500244v', 'FOMTH010');
INSERT INTO `eccoordinatortbl` VALUES ('ECC056', '952500243v', 'DipE001');
INSERT INTO `eccoordinatortbl` VALUES ('ECC067', '982500246v', 'FOMTH010');
INSERT INTO `eccoordinatortbl` VALUES ('ECC090', '942500242v', 'DipE001');
INSERT INTO `eccoordinatortbl` VALUES ('ECC091', '972500245v', 'SE001');

-- --------------------------------------------------------

-- 
-- Table structure for table `ecmanagertbl`
-- 

CREATE TABLE `ecmanagertbl` (
  `ECMId` varchar(12) NOT NULL default '',
  `NICNumber` varchar(12) NOT NULL default '',
  PRIMARY KEY  (`ECMId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `ecmanagertbl`
-- 

INSERT INTO `ecmanagertbl` VALUES ('ECM001', '8290567812v');
INSERT INTO `ecmanagertbl` VALUES ('ECM002', '8390567813v');
INSERT INTO `ecmanagertbl` VALUES ('ECM021', '8490567814v');
INSERT INTO `ecmanagertbl` VALUES ('ECM034', '8590567815v');
INSERT INTO `ecmanagertbl` VALUES ('ECM067', '8690567816v');
INSERT INTO `ecmanagertbl` VALUES ('ECM020', '8790567817v');
INSERT INTO `ecmanagertbl` VALUES ('ECM023', '8890567818v');

-- --------------------------------------------------------

-- 
-- Table structure for table `ecstaff`
-- 

CREATE TABLE `ecstaff` (
  `NICNumber` varchar(12) NOT NULL default '',
  `FirstName` varchar(30) NOT NULL default '',
  `LastName` varchar(30) NOT NULL default '',
  `DOB` date NOT NULL default '0000-00-00',
  `Age` int(11) default NULL,
  `Gender` varchar(10) default NULL,
  `EmailAddress` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `ecstaff`
-- 

INSERT INTO `ecstaff` VALUES ('922500249v', 'Estelle', 'Kautzer', '1993-02-20', 23, 'Female', 'Mozelle_Sawayn@maddison.net');
INSERT INTO `ecstaff` VALUES ('909125430v', 'Amila', 'Udayanga', '1990-02-20', 26, 'Male', 'amilaudayanga@gmail.com');
INSERT INTO `ecstaff` VALUES ('929125432v', 'Toney', 'Wokker', '1992-10-23', 25, 'Male', 'Mozelle_Sawayn@maddison.net');
INSERT INTO `ecstaff` VALUES ('939125433v', 'Murry', 'Renhunt', '1993-11-30', 23, 'Male', 'Mozelle_Sawayn@maddison.net');
INSERT INTO `ecstaff` VALUES ('932500241v', 'Gregg', ' Wehner', '1993-04-12', 23, 'Female', 'Gregg@Yahoo.com');
INSERT INTO `ecstaff` VALUES ('922500240v', 'Shawna', 'Kautzer', '1992-11-22', 25, 'Male', 'ShawnaKutzer@Google.com');
INSERT INTO `ecstaff` VALUES ('972500245v', 'Sid', 'Doyle', '1997-02-20', 20, 'Female', 'Sid1997@gmail.com');
INSERT INTO `ecstaff` VALUES ('8290567812v', 'Deja', 'Watson', '1982-05-30', 39, 'Female', 'Maybelle.Treutel@ josephine.co.uk');
INSERT INTO `ecstaff` VALUES ('8390567813v', 'Adolfo', 'Gerhold', '1983-02-20', 36, 'Female', 'Jamarcus.Wilkinson@molly.biz');
INSERT INTO `ecstaff` VALUES ('8490567814v', 'Gerhold', 'Wilber', '1984-09-21', 37, 'Female', 'Laurianne@mathew.co.uk');

-- --------------------------------------------------------

-- 
-- Table structure for table `ecstafftele`
-- 

CREATE TABLE `ecstafftele` (
  `NICNumber` varchar(12) NOT NULL default '',
  `Type` varchar(15) NOT NULL default '',
  `TeleNumber` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`,`TeleNumber`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `ecstafftele`
-- 

INSERT INTO `ecstafftele` VALUES ('922500240v', 'Mobile', '0702889087');
INSERT INTO `ecstafftele` VALUES ('922500240v', 'Home', '(094) 41 341 63');
INSERT INTO `ecstafftele` VALUES ('8890567818v', 'Home', '(973)4733201');
INSERT INTO `ecstafftele` VALUES ('8890567818v', 'Moble', '(790)8332875');
INSERT INTO `ecstafftele` VALUES ('929125432v', 'Home', '(413)9423317');
INSERT INTO `ecstafftele` VALUES ('939125433v', 'Home', '(385)5932256');
INSERT INTO `ecstafftele` VALUES ('972500245v', 'Home', '(121)6890447');
INSERT INTO `ecstafftele` VALUES ('8390567813v', 'Home', '(395)4702700');

-- --------------------------------------------------------

-- 
-- Table structure for table `email`
-- 

CREATE TABLE `email` (
  `EmailId` varchar(12) NOT NULL default '',
  `Content` varchar(200) NOT NULL default '',
  `SubmitDate` date NOT NULL default '0000-00-00',
  `NICNumber` varchar(12) NOT NULL default '',
  `EvidanveId` varchar(249) NOT NULL default '',
  PRIMARY KEY  (`EmailId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `email`
-- 

INSERT INTO `email` VALUES ('E001', 'Clearly provide evidance for him incident', '2017-03-27', '8725002400v', 'img2017/03/2');
INSERT INTO `email` VALUES ('E002', 'Bad Claim report submition', '2017-01-20', '922500240v', 'Document/_Ex_Parte_Pinochet_Cook__Helena_.pdf');
INSERT INTO `email` VALUES ('E003', 'Good claim submition. gave approved for the claim', '2017-03-03', '8725002400v', 'img2017/03/24CHC_Guide_for_Teachers_TEs.pdf');
INSERT INTO `email` VALUES ('E005', 'Good claim Submission', '2017-02-30', '8725002400v', 'img2017/03/24plantiff 1.docx');
INSERT INTO `email` VALUES ('E006', 'Bad submission', '2017-02-20', '8725002400v', 'img2017/03/24Weerawansa V. The Attorney ...pdf');

-- --------------------------------------------------------

-- 
-- Table structure for table `evidance`
-- 

CREATE TABLE `evidance` (
  `EvidanveId` varchar(12) NOT NULL default '',
  `EC_ClaimId` varchar(249) NOT NULL default '',
  `UploadDate` date NOT NULL default '0000-00-00',
  `Type` varchar(30) NOT NULL default '',
  `Link` varchar(240) NOT NULL default '',
  PRIMARY KEY  (`EvidanveId`,`EC_ClaimId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `evidance`
-- 

INSERT INTO `evidance` VALUES ('EVD001', 'img2017/03/24plantiff 1.docx', '2017-02-02', 'Medicale claim', 'Evidance/cl1.jpg');
INSERT INTO `evidance` VALUES ('EVD002', 'img2017/03/24Weerawansa V. The Attorney ...pdf', '2017-01-09', 'Student Leave claim', 'Evidance/cl2.jpg');
INSERT INTO `evidance` VALUES ('EVD003', 'CLAIM00003', '2017-01-20', 'Medicale claim', 'E:\\CD\\New folder');
INSERT INTO `evidance` VALUES ('EVD004', 'CLAIM00004', '2017-02-00', 'Clinical claim', 'E:\\Amila\\New folder');
INSERT INTO `evidance` VALUES ('EVD005', 'CLAIM00005', '2017-01-20', 'Student leave claim', 'E:\\Claim\\New folder');
INSERT INTO `evidance` VALUES ('EVD006', 'CLAIM00006', '2017-01-23', 'Accedent claim', 'D:\\accedentClaim\\New');
INSERT INTO `evidance` VALUES ('EVD007', 'CLAIM00007', '2017-03-23', 'Hospital admite clim', 'D:\\Asiri\\Patient');

-- --------------------------------------------------------

-- 
-- Table structure for table `faculty`
-- 

CREATE TABLE `faculty` (
  `facultyId` varchar(12) NOT NULL default '',
  `ACYId` varchar(12) NOT NULL default '',
  `Name` varchar(50) NOT NULL default '',
  `Section` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`facultyId`,`ACYId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `faculty`
-- 

INSERT INTO `faculty` VALUES ('SE001', 'SE0012016', 'Software Engineering', 'Section A');
INSERT INTO `faculty` VALUES ('NE001', ' SE0012016', 'Network Engineering', 'Section A');
INSERT INTO `faculty` VALUES ('DipE001', 'AY003221', 'Diploma In English', 'Section B');
INSERT INTO `faculty` VALUES ('DipE001', 'SE0012016', 'Diploma In English', 'Section C');
INSERT INTO `faculty` VALUES ('DipNet006', 'AY003333', 'Diploma In network', 'Section D');
INSERT INTO `faculty` VALUES ('FOM001', 'AY003019', 'facilty of Medicine', 'Section A');
INSERT INTO `faculty` VALUES ('FOMTH010', 'AY003019', 'Faculty of Mathematic', 'Section C');
INSERT INTO `faculty` VALUES ('SE001', 'SE002017', 'Faculty of Computer Science', 'Section A');
INSERT INTO `faculty` VALUES ('', ' ECC023', '', '');
INSERT INTO `faculty` VALUES ('vvvvvvvvv', ' ECC012', 'vvv', 'vv');

-- --------------------------------------------------------

-- 
-- Table structure for table `logintbl`
-- 

CREATE TABLE `logintbl` (
  `NICNumber` varchar(12) NOT NULL default '',
  `UserName` varchar(20) NOT NULL default '',
  `Password` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `logintbl`
-- 

INSERT INTO `logintbl` VALUES ('8725002400v', 'LEAD123', 'LEAD@123');
INSERT INTO `logintbl` VALUES ('922500241v', 'LEAD', 'LEAD@123');
INSERT INTO `logintbl` VALUES ('909125430v', 'LEAD123', 'LEAD@123');
INSERT INTO `logintbl` VALUES ('8490567814v', 'LEAD123', 'LEAD@123');
INSERT INTO `logintbl` VALUES ('922500240v', 'LEAD123', 'LEAD@123');

-- --------------------------------------------------------

-- 
-- Table structure for table `shedule`
-- 

CREATE TABLE `shedule` (
  `SheduleId` varchar(12) NOT NULL default '',
  `EC_ClaimId` varchar(12) NOT NULL default '',
  `StartDate` date NOT NULL default '0000-00-00',
  `EndDate` date NOT NULL default '0000-00-00',
  `CurrentStatues` varchar(40) NOT NULL default '',
  `SType` varchar(60) NOT NULL default '',
  PRIMARY KEY  (`SheduleId`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `shedule`
-- 

INSERT INTO `shedule` VALUES ('SH00001', 'CLAIM00001', '2017-01-01', '2017-02-02', 'Available', 'Good Managmet');
INSERT INTO `shedule` VALUES ('SH00002', 'CLAIM00002', '0000-00-00', '2017-03-03', 'Available', 'All are acheved');
INSERT INTO `shedule` VALUES ('SH00003', 'CLAIM00001', '2016-10-10', '2017-01-10', 'Closed', 'Low enterance');
INSERT INTO `shedule` VALUES ('SH00004', 'CLAIM00006', '2017-01-02', '2017-01-30', 'closed', 'No Submission');
INSERT INTO `shedule` VALUES ('SH00005', 'CLAIM00007', '2017-01-23', '2017-04-04', 'Available', 'Bussiness');
INSERT INTO `shedule` VALUES ('SH00006', 'CLAIM00004', '2017-01-01', '2017-01-29', 'Closed', 'English submission');
INSERT INTO `shedule` VALUES ('SH00007', 'CLAIM00005', '2017-03-21', '2017-03-30', 'Available', 'Languages Submission');
INSERT INTO `shedule` VALUES ('wwwwwwww', 'wwwwwww', '1111-11-11', '0000-00-00', 'Available', 'dddddd');
INSERT INTO `shedule` VALUES ('ssssssss', 'wwwwwww', '1111-11-11', '0000-00-00', 'Available', 'dddddd');
INSERT INTO `shedule` VALUES ('dddddddd', 'wwwwwww', '1111-11-11', '0000-00-00', 'Available', 'dddddd');
INSERT INTO `shedule` VALUES ('ffffffff', 'wwwwwww', '1111-11-11', '0000-00-00', 'Available', 'dddddd');
INSERT INTO `shedule` VALUES ('cvvvvvvvvvv', 'wwwwwww', '1111-11-11', '0000-00-00', 'Available', 'dddddd');
INSERT INTO `shedule` VALUES ('cccvvvvc', 'ccvvxxzz', '2017-12-12', '2017-12-12', 'Available', 'dddd');
INSERT INTO `shedule` VALUES ('SH000022', 'CLAIM00002', '0000-00-00', '0000-00-00', 'Available', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `stproftbl`
-- 

CREATE TABLE `stproftbl` (
  `NICNumber` varchar(12) NOT NULL default '',
  `Link` varchar(240) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `stproftbl`
-- 

INSERT INTO `stproftbl` VALUES ('8725002400v', 'images\\prof\\IMG_0020.jpg');
INSERT INTO `stproftbl` VALUES ('909125430v', 'images\\prof\\IMG_0025.jpg');
INSERT INTO `stproftbl` VALUES ('8490567814v', 'images\\prof\\IMG_0029.jpg');
INSERT INTO `stproftbl` VALUES ('922500240v', 'images\\prof\\IMG_0021.jpg');

-- --------------------------------------------------------

-- 
-- Table structure for table `student`
-- 

CREATE TABLE `student` (
  `NICNumber` varchar(12) NOT NULL default '',
  `facultyId` varchar(12) NOT NULL default '',
  `FirstName` varchar(30) NOT NULL default '',
  `LastName` varchar(30) NOT NULL default '',
  `DOB` date NOT NULL default '0000-00-00',
  `Age` int(3) NOT NULL default '0',
  `Gender` varchar(15) NOT NULL default '',
  `EmailAddress` varchar(60) NOT NULL default '',
  `Street` varchar(30) NOT NULL default '',
  `City` varchar(20) NOT NULL default '',
  `PostalCode` int(10) NOT NULL default '0',
  `Country` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `student`
-- 

INSERT INTO `student` VALUES ('9999078983v', 'M001', 'Kamal', 'Udayanga', '1999-09-09', 17, 'Male', 'amilaudayangaak1992@gmail.com', '821 Kristopher Estates', 'Dewayneberg', 84711, 'Fiji');
INSERT INTO `student` VALUES ('929090889v', 'M001', 'Shanika', 'Sewwandhi', '1992-09-06', 24, 'Female', 'ShanikaSewwandi@gmail.com', 'husmman Street', 'Kurunegala', 990299934, 'Sri lanka');
INSERT INTO `student` VALUES ('8725002400v', 'SE001', 'Upeksha', 'Jayawardana', '1987-10-10', 29, 'male', 'UJRox@gmail.com', 'Anagarika darma pala rd', 'Matara', 18000, 'Sri lanka');
INSERT INTO `student` VALUES ('010037891v', 'SE001', 'Twila', 'Padberg', '2001-06-04', 15, 'Female', 'Raina@santina.com', '8674 Paula Unions', 'Joanville', 23642, 'New Caledonia');
INSERT INTO `student` VALUES ('8909237890v', 'CH005', 'Praneeth', 'Gamage', '0000-00-00', 28, 'Female', 'Ewald_Schimmel@esteban.tv', '991 Hyman Island', 'West Jonatan', 20855, 'Indonesia');

-- --------------------------------------------------------

-- 
-- Table structure for table `studenttele`
-- 

CREATE TABLE `studenttele` (
  `NICNumber` varchar(12) NOT NULL default '',
  `Type` varchar(20) NOT NULL default '',
  `TeleNumber` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`NICNumber`,`TeleNumber`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `studenttele`
-- 

INSERT INTO `studenttele` VALUES ('9999078983v', 'Home', '(850)5516840');
INSERT INTO `studenttele` VALUES ('9999078983v', 'mobile', '(897)6542530');
INSERT INTO `studenttele` VALUES ('929090889v', 'Home', '(138)71391082');
INSERT INTO `studenttele` VALUES ('929090889v', 'Mobile', '(641)8549483');
INSERT INTO `studenttele` VALUES ('8725002400v', 'Home', '(192)5601401');
INSERT INTO `studenttele` VALUES ('010037891v', 'Home', '(395)4702700');
INSERT INTO `studenttele` VALUES ('8909237890v', 'Mobile', '(121)6890447');
